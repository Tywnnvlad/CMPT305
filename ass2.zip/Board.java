
public class Board{

    private static int boardSize = 5;
    public static int row = boardSize;
    public static int column = boardSize;

    public static void main(String[] args) {
        System.out.println("I exist");
        char [][] board =  new char[boardSize][boardSize];
        for (int i = 0; i < boardSize; i++) {
            System.out.println(" ");
            for (int j = 0; j < boardSize; j++) {
                board[i][j]= '-';
                System.out.print('-');
            }
            
        }
        Systen.out.println(" ");

    }

    public static int getRows(){
        return row;
    }
    public static int getColumn(){
        return column;
    }


}